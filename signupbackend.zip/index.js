
const { urlencoded } = require('body-parser');
const { log } = require('console');
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const path = require('path');
const port =8000;
app.use(express.json());
app.use(express.urlencoded({extended:false}));
mongoose.connect('mongodb://localhost:27017/tut1')
.then(()=>{
    console.log("mongoose connected");

})
.catch((err)=>{
console.log("error :",err);
});

app.set("view engine","ejs");
app.set("views",path.resolve("./views"));


app.get("/user/:id",async(req,res)=>{
    try {
        const getuser = await collection.findById(req.params.id);
        if (!getuser) {
            return res.status(404).json({ failed: "User not found" });
        }
       return res.render("index");
        // return res.status(200).json(getuser);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: "An error occurred" });
    }
});
app.post("/user",async(req,res)=>{
    const body = req.body;
    if(!body.firstname||!body.lastname||!body.email||!body.gender){
        return res.json({ status:"insufficient info"});
    }
    const createuser = collection.create({
        firstname:body.firstname,
        lastname:body.lastname,
        email:body.email,
        gender:body.gender
    })
    console.log(createuser);
    console.log(req.body);
    return res.status(201).json({status:"success"});

});
app.patch("/user/:id",async(req,res)=>{
    try{
        const updates = req.body;


        const editUser = await collection.findByIdAndUpdate(req.params.id, updates);
        if (!editUser) {
            return res.status(404).json({ failed: "User not found" });
        }
        return res.status(200).json({ status: "success", data: editUser });
    }

 catch (error) {
    console.log(error);
    return res.status(500).json({ error: "An error occurred" });

}

});

app.delete("/user/:id", async (req, res) => {
    try {
        const deletedUser = await collection.findByIdAndDelete(req.params.id);
        if (!deletedUser) {
            return res.status(404).json({ failed: "User not found" });
        }
        return res.status(200).json({ status: "success", data: deletedUser });
    } catch (error) {
        return res.status(500).json({ error: "An error occurred" });
    }
});


const userschema = new mongoose.Schema({

    firstname:{
                type:String,
                required:true,
            },
            lastname:{
                type:String,
              
            },
            email:{
                type:String,
                required:true,
            },
            gender:{
                type:String,
                required:true,
            },
});
const collection = mongoose.model('user',userschema);


const signupschema = new mongoose.Schema({

         name:{
                type:String,
                required:true,
            },
            
            email:{
                type:String,
                required:true,
                unique:true
            },
            password:{
                type:String,
                required:true,
            },
});

const signup = mongoose.model('newuser',signupschema);



app.post("/",async(req,res)=>{

    const {name,email,password}=req.body;
        await signup.create({
          name,
          email,
          password,
        })
    
        console.log("Successfully created new user");
        return res.redirect("https://chatgpt.com/");
   
})
app.get("/signup",async(req,res)=>{
    return res.render("signup");
})









app.listen(port,()=>{
    console.log("server start");
})