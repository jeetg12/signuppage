const { urlencoded } = require('body-parser');
const { log } = require('console');
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const path = require('path');
const port =8000;
app.use(express.json());
app.use(express.urlencoded({extended:false}));
mongoose.connect('mongodb://localhost:27017/tut')
.then(()=>{
    console.log("mongoose connected");

})
.catch((err)=>{
console.log("error :",err);
});

app.set("view engine","ejs");
app.set("views",path.resolve("./views"));

const signupschema = new mongoose.Schema({

    name:{
           type:String,
           required:true,
       },
       
       email:{
           type:String,
           required:true,
           unique:true
       },
       password:{
           type:String,
           required:true,
       },
});

const signup = mongoose.model('newuser',signupschema);



app.post("/",async(req,res)=>{

const {name,email,password}=req.body;
   await signup.create({
     name,
     email,
     password,
   })

   console.log("Successfully created new user");
   return res.redirect("https://chatgpt.com/");

})
app.get("/signup",async(req,res)=>{
return res.render("signup");
})









app.listen(port,()=>{
console.log("server start");
})